# 模板

Authoring Tools提供快速制作AR内容的一系列模板。模板中预置了用于展示的模型素材，以及编写了AR交互体验的AR Script脚本。

参考：[指尖跟随模板](/chu-ji-gong-zuo-liu/zhi-jian-gen-sui-mo-ban-jie-shao.md)

通过将模版中的模型素材替换为用户自定义的模型素材，并且修改AR Script中的一些关键参数，用户可以快速的将3D美术素材AR化。

如果用户具有一定的编程基础，还可以修改模版中的AR Script脚本，实现更多自定义的功能。



